import { BrowserRouter, Routes, Route } from "react-router-dom";

import ProtectedRoute from "./routes/ProtectedRoute";

import PublicDashboard from "./pages/public/PublicDashboard";
import Login from "./pages/Login";
import Register from "./pages/Register";

import UserDashboard from "./pages/user/UserDashboard";
import UserAppointments from "./pages/user/Appointments";
import BookAppointment from "./pages/user/BookAppointment";
import Profile from "./pages/user/Profile";
import Reports from "./pages/user/Reports";
import ReportDetails from "./pages/user/ReportDetails";
import UploadReport from "./pages/user/UploadReport";
import Patients from "./pages/admin/Patients";
import PatientDetails from "./pages/admin/PatientDetails";
import Doctors from "./pages/admin/Doctors";
import DoctorDetails from "./pages/admin/DoctorDetails";
import AdminAppointments from "./pages/admin/AdminAppointments";
import AppointmentDetails from "./pages/admin/AppointmentDetails";
import AdminReports from "./pages/admin/Reports";
import AdminReportDetails from "./pages/admin/ReportDetails";

import AdminDashboard from "./pages/admin/AdminDashboard";

function App() {
  return (
    <BrowserRouter>
      <Routes>

        {/* PUBLIC */}

        <Route
          path="/"
          element={<PublicDashboard />}
        />

        <Route
          path="/public/dashboard"
          element={<PublicDashboard />}
        />

        <Route
          path="/login"
          element={<Login />}
        />

        <Route
          path="/register"
          element={<Register />}
        />


        {/* USER */}

        <Route
          path="/user/dashboard"
          element={
            <ProtectedRoute>
              <UserDashboard />
            </ProtectedRoute>
          }
        />

        <Route
          path="/user/appointments"
          element={
            <ProtectedRoute>
              <UserAppointments />
            </ProtectedRoute>
          }
        />

        <Route
          path="/user/book-appointment"
          element={
            <ProtectedRoute>
              <BookAppointment />
            </ProtectedRoute>
          }
        />

        <Route
          path="/user/profile"
          element={
            <ProtectedRoute>
              <Profile />
            </ProtectedRoute>
          }
        />

        <Route
          path="/user/reports"
          element={
            <ProtectedRoute>
              <Reports />
            </ProtectedRoute>
          }
        />

        <Route
          path="/user/reports/:id"
          element={
            <ProtectedRoute>
              <ReportDetails />
            </ProtectedRoute>
          }
        />

        <Route
          path="/user/upload-report"
          element={
            <ProtectedRoute>
              <UploadReport />
            </ProtectedRoute>
          }
        />


        {/* ADMIN */}

        <Route
          path="/admin/dashboard"
          element={
            <ProtectedRoute>
              <AdminDashboard />
            </ProtectedRoute>
          }
        />

        <Route
          path="/admin/patients"
          element={
            <ProtectedRoute>
              <Patients />
            </ProtectedRoute>
          }
        />

        <Route
          path="/admin/patients/:id"
          element={
            <ProtectedRoute>
              <PatientDetails />
            </ProtectedRoute>
          }
        />

        <Route
          path="/admin/doctors"
          element={
            <ProtectedRoute>
              <Doctors />
            </ProtectedRoute>
          }
        />

        <Route
          path="/admin/doctors/:id"
          element={
            <ProtectedRoute>
              <DoctorDetails />
            </ProtectedRoute>
          }
        />

        <Route
          path="/admin/appointments"
          element={
            <ProtectedRoute>
              <AdminAppointments />
            </ProtectedRoute>
          }
        />

        <Route
          path="/admin/appointments/:id"
          element={
            <ProtectedRoute>
              <AppointmentDetails />
            </ProtectedRoute>
          }
        />

        <Route
          path="/admin/reports"
          element={<AdminReports />}
        />

        <Route
          path="/admin/reports/:id"
          element={<AdminReportDetails />}
        />

      </Routes>
    </BrowserRouter>
  );
}

export default App;