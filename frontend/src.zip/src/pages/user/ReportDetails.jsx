import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import "./ReportDetails.css";

function ReportDetails() {
  const { id } = useParams();

  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(true);

  const token = localStorage.getItem("token");

  useEffect(() => {
    const fetchReport = async () => {
      try {
        const response = await fetch(
          `http://localhost:5000/api/reports/${id}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        const data = await response.json();

        if (response.ok) {
          setReport(data.report);
        } else {
          console.error(data.message);
        }
      } catch (error) {
        console.error("Report Details Error:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchReport();
  }, [id, token]);

  if (loading) {
    return (
      <div className="report-details-page">
        <div className="report-loading">
          <div>⏳</div>
          <h3>Loading report...</h3>
        </div>
      </div>
    );
  }

  if (!report) {
    return (
      <div className="report-details-page">
        <div className="report-not-found">
          <div>📄</div>
          <h2>Report not found</h2>

          <Link to="/user/reports">
            ← Back to Reports
          </Link>
        </div>
      </div>
    );
  }

  const analysis = report.aiAnalysis;

  return (
    <div className="report-details-page">

      {/* Navbar */}
      <nav className="report-details-navbar">

        <Link
          to="/user/reports"
          className="back-link"
        >
          ← My Reports
        </Link>

        <div className="report-hospital">
          <span>✚</span>
          <strong>City Hospital</strong>
        </div>

      </nav>

      {/* Header */}
      <section className="report-details-header">

        <div>
          <span>MEDICAL REPORT</span>

          <h1>
            {report.reportName}
          </h1>

          <p>
            {report.reportType}
            {" • "}
            {report.createdAt
              ? new Date(
                  report.createdAt
                ).toLocaleDateString()
              : ""}
          </p>
        </div>

        <div
          className={`detail-status ${
            report.status?.toLowerCase()
          }`}
        >
          {report.status}
        </div>

      </section>

      {/* Processing */}
      {report.status === "Processing" && (
        <div className="processing-banner">

          <div className="processing-banner-icon">
            ⏳
          </div>

          <div>
            <strong>
              Your report is being analyzed
            </strong>

            <p>
              Our AI is currently analyzing your
              report. You can explore other features
              while we process it. Once complete,
              the analysis will also be sent to your
              registered email.
            </p>
          </div>

        </div>
      )}

      {/* Failed */}
      {report.status === "Failed" && (
        <div className="failed-banner">
          <strong>
            AI analysis could not be completed.
          </strong>

          <p>
            Please try uploading the report again
            or consult a qualified healthcare
            professional.
          </p>
        </div>
      )}

      {/* AI Analysis */}
      {report.status === "Analyzed" && analysis && (
        <main className="analysis-container">

          {/* Summary */}
          <section className="analysis-card summary-card">

            <div className="analysis-label">
              AI REPORT SUMMARY
            </div>

            <h2>
              Understanding your report
            </h2>

            <p>
              {analysis.summary ||
                "No summary available."}
            </p>

          </section>

          {/* Key Findings */}
          <section className="analysis-card">

            <div className="analysis-label">
              KEY FINDINGS
            </div>

            <h2>
              What the report shows
            </h2>

            <div className="finding-list">

              {(analysis.keyFindings || []).length > 0 ? (
                analysis.keyFindings.map(
                  (finding, index) => (
                    <div
                      className="finding-item"
                      key={index}
                    >
                      <span>✓</span>
                      <p>{finding}</p>
                    </div>
                  )
                )
              ) : (
                <p className="no-data">
                  No key findings reported.
                </p>
              )}

            </div>

          </section>

          {/* Abnormal Values */}
          <section className="analysis-card">

            <div className="analysis-label">
              ABNORMAL VALUES
            </div>

            <h2>
              Values requiring attention
            </h2>

            {(analysis.abnormalValues || []).length > 0 ? (

              <div className="abnormal-list">

                {analysis.abnormalValues.map(
                  (value, index) => (
                    <div
                      className="abnormal-item"
                      key={index}
                    >
                      ⚠️ {value}
                    </div>
                  )
                )}

              </div>

            ) : (

              <div className="normal-result">
                ✓ No abnormal values were identified
                by the AI analysis.
              </div>

            )}

          </section>

          {/* Possible Concerns */}
          <section className="analysis-card">

            <div className="analysis-label">
              POSSIBLE CONCERNS
            </div>

            <h2>
              Things to discuss with your doctor
            </h2>

            {(analysis.possibleConcerns || []).length > 0 ? (

              <ul className="concern-list">
                {analysis.possibleConcerns.map(
                  (concern, index) => (
                    <li key={index}>
                      {concern}
                    </li>
                  )
                )}
              </ul>

            ) : (

              <p className="no-data">
                No specific concerns were identified.
              </p>

            )}

          </section>

          {/* Medication */}
          <section className="analysis-card medication-card">

            <div className="analysis-label">
              COMMON MEDICATION INFORMATION
            </div>

            <h2>
              General information only
            </h2>

            {(analysis.commonMedicationInformation || []).length > 0 ? (

              <ul className="medication-list">

                {analysis.commonMedicationInformation.map(
                  (medicine, index) => (
                    <li key={index}>
                      {medicine}
                    </li>
                  )
                )}

              </ul>

            ) : (

              <p className="no-data">
                No common medication information was
                provided for this report.
              </p>

            )}

            <div className="medication-warning">
              <strong>⚠ Important</strong>

              <p>
                Do not start, stop, or change any
                medication based only on this AI
                information. Please consult a qualified
                doctor before taking any medicine.
              </p>
            </div>

          </section>

          {/* Recommendations */}
          <section className="analysis-card">

            <div className="analysis-label">
              GENERAL RECOMMENDATIONS
            </div>

            <h2>
              General health guidance
            </h2>

            <ul className="recommendation-list">

              {(analysis.generalRecommendations || []).map(
                (recommendation, index) => (
                  <li key={index}>
                    {recommendation}
                  </li>
                )
              )}

            </ul>

          </section>

          {/* Doctor Advice */}
          <section className="analysis-card doctor-advice-card">

            <div className="analysis-label">
              DOCTOR'S ADVICE
            </div>

            <h2>
              What you should do next
            </h2>

            <p>
              {analysis.doctorAdvice ||
                "Please consult a qualified doctor."}
            </p>

          </section>

          {/* Disclaimer */}
          <section className="ai-disclaimer">

            <strong>
              ⚠ AI-GENERATED INFORMATION
            </strong>

            <p>
              {analysis.disclaimer ||
                "This information is AI-generated and may contain mistakes. It is not a medical diagnosis or prescription. Please consult a qualified doctor before taking any medication or making medical decisions."}
            </p>

          </section>

        </main>
      )}

    </div>
  );
}

export default ReportDetails;