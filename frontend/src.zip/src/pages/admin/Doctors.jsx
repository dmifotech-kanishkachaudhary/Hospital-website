import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./Doctors.css";

function Doctors() {
  const navigate = useNavigate();

  const [doctors, setDoctors] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const token = localStorage.getItem("token");

  const fetchDoctors = async (
    searchValue = ""
  ) => {
    try {
      setLoading(true);
      setError("");

      const url = searchValue.trim()
        ? `http://localhost:5000/api/doctors?search=${encodeURIComponent(
            searchValue.trim()
          )}`
        : "http://localhost:5000/api/doctors";

      const response = await fetch(url, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.message ||
            "Failed to fetch doctors"
        );
      }

      setDoctors(data.doctors || []);
    } catch (error) {
      console.error(
        "Doctors Error:",
        error
      );

      setError(error.message);
      setDoctors([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDoctors();
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    fetchDoctors(search);
  };

  const handleClear = () => {
    setSearch("");
    fetchDoctors();
  };

  return (
    <div className="admin-doctors-page">

      {/* ================= NAVBAR ================= */}

      <nav className="admin-page-navbar">

        <Link
          to="/admin/dashboard"
          className="admin-page-logo"
        >
          <span>✚</span>

          <div>
            <strong>
              City Hospital
            </strong>

            <small>
              Admin Portal
            </small>
          </div>
        </Link>

        <div className="admin-page-nav">

          <Link to="/admin/dashboard">
            Dashboard
          </Link>

          <Link
            to="/admin/patients"
          >
            Patients
          </Link>

          <Link
            to="/admin/doctors"
            className="active"
          >
            Doctors
          </Link>

          <Link
            to="/admin/appointments"
          >
            Appointments
          </Link>

          <Link
            to="/admin/reports"
          >
            Reports
          </Link>

        </div>

        <button
          className="admin-logout"
          onClick={() => {
            localStorage.removeItem(
              "token"
            );

            localStorage.removeItem(
              "user"
            );

            window.location.href =
              "/login";
          }}
        >
          Logout
        </button>

      </nav>


      {/* ================= MAIN ================= */}

      <main className="admin-doctors-container">

        {/* HEADER */}

        <div className="admin-doctors-header">

          <div>

            <span>
              MEDICAL STAFF MANAGEMENT
            </span>

            <h1>
              Doctors
            </h1>

            <p>
              Search and manage hospital
              doctors.
            </p>

          </div>

          <div className="doctor-count">

            <strong>
              {doctors.length}
            </strong>

            <span>
              {search
                ? "Matching Doctors"
                : "Doctors"}
            </span>

          </div>

        </div>


        {/* SEARCH */}

        <form
          className="doctor-search"
          onSubmit={handleSearch}
        >

          <div className="doctor-search-input">

            <span>⌕</span>

            <input
              type="text"
              placeholder="Search by Doctor ID, name, email, specialization or department..."
              value={search}
              onChange={(e) =>
                setSearch(e.target.value)
              }
            />

          </div>

          <button type="submit">
            Search
          </button>

          {search && (
            <button
              type="button"
              className="clear-doctor-search"
              onClick={handleClear}
            >
              Clear
            </button>
          )}

        </form>


        {/* ERROR */}

        {error && (
          <div className="doctors-error">
            {error}
          </div>
        )}


        {/* DOCTOR LIST */}

        <section className="doctors-table-card">

          <div className="doctors-table-heading">

            <div>

              <span>
                REGISTERED MEDICAL STAFF
              </span>

              <h2>
                Doctor List
              </h2>

            </div>

          </div>


          {loading ? (

            <div className="doctors-state">

              <div>⏳</div>

              <h3>
                Loading doctors...
              </h3>

              <p>
                Please wait while we
                fetch doctor records.
              </p>

            </div>

          ) : doctors.length === 0 ? (

            <div className="doctors-state">

              <div>👨‍⚕️</div>

              <h3>
                No doctors found
              </h3>

              <p>
                Try searching with a
                different name,
                specialization or
                department.
              </p>

            </div>

          ) : (

            <div className="doctors-table-wrapper">

              <table className="doctors-table">

                <thead>

                  <tr>
                    <th>
                      Doctor ID
                    </th>

                    <th>
                      Doctor
                    </th>

                    <th>
                      Email
                    </th>

                    <th>
                      Specialization
                    </th>

                    <th>
                      Department
                    </th>

                    <th>
                      Experience
                    </th>

                    <th>
                      Availability
                    </th>

                    <th>
                      Action
                    </th>
                  </tr>

                </thead>

                <tbody>

                  {doctors.map(
                    (doctor) => (

                      <tr
                        key={
                          doctor._id
                        }
                      >

                        <td>

                          <span className="doctor-id">
                            {doctor._id.slice(
                              -8
                            )}
                          </span>

                        </td>


                        <td>

                          <div className="doctor-name">

                            <div className="doctor-avatar">
                              👨‍⚕️
                            </div>

                            <strong>
                              {doctor.name ||
                                "Unknown"}
                            </strong>

                          </div>

                        </td>


                        <td>
                          {doctor.email ||
                            "N/A"}
                        </td>


                        <td>
                          {doctor.specialization ||
                            "N/A"}
                        </td>


                        <td>
                          {doctor.department ||
                            "N/A"}
                        </td>


                        <td>
                          {doctor.experience ??
                            0}{" "}
                          years
                        </td>


                        <td>

                          <span
                            className={
                              doctor.availability
                                ?.toLowerCase() ===
                              "available"
                                ? "doctor-available"
                                : "doctor-unavailable"
                            }
                          >
                            {doctor.availability ||
                              "Available"}
                          </span>

                        </td>


                        <td>

                          <button
                            className="view-doctor-btn"
                            onClick={() =>
                              navigate(
                                `/admin/doctors/${doctor._id}`
                              )
                            }
                          >
                            View Details →
                          </button>

                        </td>

                      </tr>

                    )
                  )}

                </tbody>

              </table>

            </div>

          )}

        </section>

      </main>

    </div>
  );
}

export default Doctors;